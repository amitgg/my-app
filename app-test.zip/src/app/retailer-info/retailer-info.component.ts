import { Component, OnInit } from '@angular/core';
import { FormControl, NgModel } from '@angular/forms';

@Component({
  selector: 'app-retailer-info',
  templateUrl: './retailer-info.component.html',
  styleUrls: ['./retailer-info.component.css']
})
export class RetailerInfoComponent implements OnInit {
  a;
  b;
  constructor() { 
    
  }

  ngOnInit() {
  }

}
